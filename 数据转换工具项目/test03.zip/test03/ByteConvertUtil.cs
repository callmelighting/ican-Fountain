using System;

public class ByteConvertUtil
{
    // 更新末位数组
    public static void UpDateEndArray(byte[] result, byte value4, byte value5, byte value6,
            byte value7, byte value8, byte value9, byte value10, byte value11)
    {
        for (int i = 7; i >= 0; i--)
        {
            // 获取最低位
            result[i] = (byte)(value4 & 1);
            result[i + 8] = (byte)(value5 & 1);
            result[i + 16] = (byte)(value6 & 1);
            result[i + 24] = (byte)(value7 & 1);
            result[i + 32] = (byte)(value8 & 1);
            result[i + 40] = (byte)(value9 & 1);
            result[i + 48] = (byte)(value10 & 1);
            result[i + 56] = (byte)(value11 & 1);
            // 每次右移1位
            value4 = (byte)(value4 >> 1);
            value5 = (byte)(value5 >> 1);
            value6 = (byte)(value6 >> 1);
            value7 = (byte)(value7 >> 1);
            value8 = (byte)(value8 >> 1);
            value9 = (byte)(value9 >> 1);
            value10 = (byte)(value10 >> 1);
            value11 = (byte)(value11 >> 1);
        }
    }

    // 二进制转十进制
    public static int B2D(byte[] bytes)
    {
        int result = 0;
        int indexEnd = bytes.Length - 1;
        for (int i = 0; i <= indexEnd; i++)
            result |= bytes[indexEnd - i] << i;
        return result;
    }

    // 截取数组
    public static byte[] CutBytes(byte[] bytes, int start, int end)
    {
        byte[] result = new byte[end - start + 1];
        Array.Copy(bytes, start, result, 0, result.Length);
        return result;
    }

    // 拆分帧数据并进行处理
    public static void SubData(byte[] bytes)
    {
        // 循环处理每一帧
        for (int i = 0; i < bytes.Length; i += 12)
        {
            // 拆出单独的一帧
            byte[] result = CutBytes(bytes, i, i + 11);
            // 处理该帧数据
            PostMerge.Add(DateTime.Now, String.Join('|', result));
        }
    }
}
