using System;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Collections.Generic;

// 客户端脚本
public class ClientScript
{
    private Queue<byte[]> dataQueue = new Queue<byte[]>(); // 数据队列
    private IPEndPoint ipEndPoint;  // 本地或远程网络端点
    private UdpClient udpClient;    // UDP客户端

    // 创建UDP客户端
    public bool CreateClient(int port)
    {
        // 尝试关闭已经存在的UDP客户端
        CloseClient();
        try
        {
            // 创建本地网络端点
            ipEndPoint = new IPEndPoint(IPAddress.Any, port);
            // 创建UDP客户端并绑定本地网络端点
            udpClient = new UdpClient(ipEndPoint);
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
            return false;
        }
        // 开始接收数据
        udpClient.BeginReceive(new AsyncCallback(ReceiveMsgCallback), null);
        return true;
    }

    // 关闭UDP客户端
    public void CloseClient()
    {
        if (udpClient != null)
        {
            udpClient.Close();
            udpClient = null;
        }
    }

    // 接收到数据
    private void ReceiveMsgCallback(IAsyncResult ar)
    {
        if (udpClient != null)
        {
            try
            {
                // 接收数据并将数据加入数据队列
                dataQueue.Enqueue(udpClient.EndReceive(ar, ref ipEndPoint));
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            // 继续接收数据
            udpClient.BeginReceive(new AsyncCallback(ReceiveMsgCallback), null);
        }
        else
        {
            Console.WriteLine("The udpClient is null!");
        }
    }

    // 处理消息列表的消息
    public void DispatchData()
    {
        // 锁定同步对象
        lock (((ICollection)dataQueue).SyncRoot)
        {
            if (dataQueue.Count > 0)
            {
                ByteConvertUtil.SubData(dataQueue.Dequeue());
            }
        }
    }
}
