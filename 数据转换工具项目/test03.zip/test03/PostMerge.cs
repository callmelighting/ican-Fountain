using System;

public class PostMerge
{
    private static double gap; // 采样时间间隔
    private static DateTime startTime; // 开始的时间
    private static DateTime lastTime; // 上次的时间

    // 初始化并设定采样时间间隔
    public static void Init(double gap)
    {
        PostMerge.gap = gap;
        PostMerge.startTime = DateTime.Now;
        PostMerge.lastTime = startTime;
    }

    // 添加一条数据
    // TODO 这部分代码存在微小的时间误差，最好修改为异步执行的方法，
    // 将可能会拖延时间的代码异步执行，进一步增加时间间隔的准确率。
    // TODO 这部分代码直接将结果输出，在使用时需将本程序放入命令行中执行。
    // 如将本程序编译为aaa.exe后，在CMD中执行aaa.exe > control.ic即可将
    // 本程序的所有内容输出到control.ic文件中。
    // TODO 本程序输出的数据并不可以直接使用，还需将开头第一行的E标签去掉，
    // 并在结尾添加E标签。简而言之，改为：
    /*
    T1000
    102|2|0|0|0|0|0|0|0|0|0|0
    ……
    E
    */
    // 的格式。
    // TODO 本程序属于半成品，但基本功能都已经实现，将来需要改为更易于使用的版本。
    public static void Add(DateTime thisTime, string line)
    {
        // 获取这次的时间间隔
        double thisGap = thisTime.Subtract(lastTime).TotalMilliseconds;
        // 如果这次的时间间隔小于预设
        if (thisGap <= gap)
        {
            // 直接输出
            Console.WriteLine(line);
        }
        else
        {
            // 反之更新时间，并插入标签
            PostMerge.lastTime = thisTime;
            Console.WriteLine("E");
            Console.WriteLine("T" + thisGap);
            Console.WriteLine(line);
        }
    }
}
