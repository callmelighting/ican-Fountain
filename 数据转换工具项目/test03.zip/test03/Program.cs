﻿using System;

namespace test03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Start!");
            new Program();
            Console.WriteLine("End!");
        }

        public Program()
        {
            // 设定采样间隔时间
            PostMerge.Init(100); // 0.1秒
            // 初始化客户端接受脚本
            ClientScript cs = new ClientScript();
            // 创建在200端口的监听
            cs.CreateClient(200);
            // 循环接受并处理信息
            while (true) cs.DispatchData();
        }
    }
}
